package servlet;

public class StatusUpdateServlet {

}
