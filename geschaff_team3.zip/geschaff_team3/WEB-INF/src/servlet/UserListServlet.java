package servlet;

import java.io.*;
import java.util.ArrayList;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;
import dao.UserDAO;

public class UserListServlet extends HttpServlet{

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String error = "";

		try {
			// UserDAOをインスタンス化する
			UserDAO userDao = new UserDAO();

			// 関連メソッドを呼び出し、戻り値としてUserオブジェクトのリストを取得する
			ArrayList<User> userList = userDao.selectAll();

			// 上で取得したarrayListをリクエストスコープに"userList"という名前で格納する
			request.setAttribute("userList", userList);

		} catch (IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
		} finally {
			// エラーの有無でフォワード先を呼び分ける
			if (error.isEmpty()) {
				// エラーが無い場合はlist.jspにフォワード
				request.getRequestDispatcher("/view/list.jsp").forward(request,response);
			} else {
				// エラーが有る場合はerror.jspにフォワードする
				request.setAttribute("error", error);
				request.getRequestDispatcher("/logout").forward(request, response);
			}
		}
	}
}
