package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Transaction;
import bean.User;
import dao.TransactionDAO;

public class PaymentStatusUpdateServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// エラー発生時に使用する変数
		String error = "";
		String cmd = "";

		String transactionId = (String) request.getParameter("transactionId");

		TransactionDAO transactionDao = new TransactionDAO();

		try {

			transactionDao.updatePaymentStatus(transactionId);

		} catch (IllegalStateException e) {

			// DB接続エラー時の処理

			error = "DB接続エラーの為、、入金確認を行うことが出来ませんでした";
			cmd = "userLogout";

		} finally {

			// エラーが発生しなければ通常の処理
			if (error.equals("")) {

				request.getRequestDispatcher("/dealList").forward(request, response);

				// エラーが発生した場合はエラーメッセージとcmdを登録し、エラー画面へ遷移
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/view/error.jsp");

				dispatcher.forward(request, response);

			}
		}

	}

}
