package servlet;

import java.io.IOException;

import javax.servlet.*;
import javax.servlet.http.*;

import bean.User;
import dao.UserDAO;

public class UserLoginServlet extends HttpServlet {

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String error = "";
		String cmd = "";
		String email = "";
		String password = "";

		try {

			//入力データの文字コードの指定
			request.setCharacterEncoding("UTF-8");

			//useridとpasswordを取得
			email = request.getParameter("email");
			password = request.getParameter("password");

			//UserDAOをインスタンス化
			UserDAO userDao = new UserDAO();

			//ユーザー情報を検索しUserオブジェクトを取得
			User user = userDao.selectByUser(email,password);

			//ユーザー情報のエラーチェック
			if(user.getEmail() == null || user.getPassword() == null) {
				cmd = "login";
				error = "error";
				return;
			}

			//セッションにユーザー情報を登録
			HttpSession session = request.getSession();
			session.setAttribute("user", user);

			//クッキーにメールアドレスを登録
			Cookie emailCookie = new Cookie("email",email);
			emailCookie.setMaxAge(60*60*24*5);
			response.addCookie(emailCookie);

			//クッキーにパスワードを登録
			Cookie passwordCookie = new Cookie("password",password);
			passwordCookie.setMaxAge(60*60*24*5);
			response.addCookie(passwordCookie);

		}catch(IllegalStateException e){
			//接続エラー
			error = "DB接続エラーの為、ログインはできません。";
			cmd = "logout";
		}finally {
			//エラーの有無でフォワード先を呼び分ける
			if(error.equals("")) {
				request.getRequestDispatcher("/view/userMenu.jsp").forward(request, response);
			} else {
				//cmdの値でフォワード先を呼び分ける
				if(cmd.equals("login")) {
					request.setAttribute("message","入力データが間違っています！");
					request.getRequestDispatcher("/view/userLogin.jsp").forward(request, response);
				}else {
					request.setAttribute("error",error);
					request.setAttribute("cmd",cmd);
					request.getRequestDispatcher("/view/error.jsp").forward(request, response);
				}
			}
		}
	}
}