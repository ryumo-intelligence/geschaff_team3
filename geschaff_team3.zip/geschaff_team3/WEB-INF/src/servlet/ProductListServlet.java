package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.ArrayList;

import bean.Product;
import dao.ProductDAO;

public class ProductListServlet extends HttpServlet {

	//doGetメソッドを定義
	public void doGet(HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//オブジェクト生成
			ProductDAO objPro = new ProductDAO();

			//配列宣言
			//selectAll()メソッドを利用して情報を取得
			ArrayList<Product> productList = objPro.selectAll();

			//リクエストスコープに登録
			request.setAttribute("productList", productList);


		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "userLogout";

		}finally {
			if(error.equals("")) {
				//フォワードの実行
				request.getRequestDispatcher("/view/productList.jsp").forward(request, response);
			} else {
			request.setAttribute("error", error);
			request.setAttribute("cmd", cmd);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}
