package servlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.ArrayList;

import bean.Product;
import dao.ProductDAO;

public class ProductListServlet {

	//doGetメソッドを定義
	public void doGet(HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//オブジェクト生成
			ProductDAO objPro = new ProductDAO();

			//配列宣言
			//selectAll()メソッドを利用して情報を取得
			ArrayList<Product> list = objPro.selectAll(); //DAO作ったらエラー直る

			//リクエストスコープに登録
			request.setAttribute("product_list", list);


		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "menu";

		}finally {
			if(error.equals("")) {
				//フォワードの実行
				request.getRequestDispatcher("/view/menu.jsp").forward(request, response);

			}
			request.setAttribute("error", error);
			request.setAttribute("cmd", cmd);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}

	}

}
