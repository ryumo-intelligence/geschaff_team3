package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.TransactionList;
import dao.TransactionListDAO;

public class EarningServlet extends HttpServlet{
	//doGetメソッドを定義
	public void doGet(HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//オブジェクト生成
			TransactionListDAO transactionListDao = new TransactionListDAO();

			//配列宣言
			//selectAll()メソッドを利用して情報を取得
			ArrayList<TransactionList> transactionList = transactionListDao.selectAll();

			int total = 0;

			for (TransactionList transactionLi : transactionList) {
				total += transactionLi.getPrice();
			}
			int profit = total/10;
			//リクエストスコープに登録
			request.setAttribute("total", total);
			request.setAttribute("profit", profit);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、一覧表示は行えませんでした。";
			cmd = "adminLogout";
		}finally {
			if(error.isEmpty()) {
				//フォワードの実行
				request.getRequestDispatcher("/view/earning.jsp").forward(request, response);
			}else {
			request.setAttribute("error", error);
			request.setAttribute("cmd", cmd);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}
		}
	}
}