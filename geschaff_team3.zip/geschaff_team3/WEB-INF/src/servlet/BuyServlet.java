package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Product;
import bean.Transaction;
import bean.User;
import dao.ProductDAO;
import dao.TransactionDAO;
import dao.UserDAO;
import util.SendMail;

public class BuyServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// エラー発生時に使用する変数
		String error = "";
		String cmd = "";

		UserDAO userDao = new UserDAO();

		ProductDAO productDao = new ProductDAO();

		TransactionDAO transactionDao = new TransactionDAO();

		Product product = new Product();

		Transaction transaction = new Transaction();

		User user = new User();

		SendMail sendmail = new SendMail();

		HttpSession session = request.getSession();

		// 取得するデータのエンコード処理
		request.setCharacterEncoding("UTF-8");

		// 商品IDを取得
		int productId = Integer.parseInt((String) request.getParameter("productId"));

		String SellerName;

		String mailText;

		try {

			// 取得したIDの商品情報を取得

			product = productDao.selectByProductId(productId);

			user = (User) session.getAttribute("user");

			// セッション切れの場合はerror.jspに遷移する
			if (user == null) {
				error = "セッション切れの為、購入処理を行えませんでした。";
				cmd = "userLogout";
				return;
			}

			transaction.setProductId(product.getProductId());
			transaction.setBuyerEmail(user.getEmail());
			transaction.setSellerEmail(product.getSellerEmail());

			transactionDao.insert(transaction);
			productDao.update(product);

			SellerName = userDao.selectBySeller(productId);
			mailText = SellerName + "様\n\n以下内容の商品のご購入が購入されましたことをご報告いたします。\n\n" + "商品名:"
					+ product.getProductName() + " 価格:" + product.getPrice() + "円"
					+ "\n\n商品発送後は取引一覧画面より発送確認ボタンを押していただきますようお願いいたします。" + "\n\nまたのご利用お待ちしております。";

			sendmail.sendmail("ご出品された商品についてのお知らせ", mailText);



		} catch (IllegalStateException e) {

			// DB接続エラー時の処理

			error = "DB接続エラーの為、、詳細情報は表示できませんでした。";
			cmd = "userLogout";
		} catch (Exception e) {
		} finally {

			// エラーが発生しなければ通常の処理
			if (error.equals("")) {

				request.getRequestDispatcher("/dealList").forward(request, response);

				// エラーが発生した場合はエラーメッセージとcmdを登録し、エラー画面へ遷移
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/view/error.jsp");

				dispatcher.forward(request, response);

			}
		}

	}

}