package servlet;

public class BuyServlet {

}
