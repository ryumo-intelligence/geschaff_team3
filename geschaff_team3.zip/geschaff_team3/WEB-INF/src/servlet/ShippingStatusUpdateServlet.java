package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Product;
import bean.Transaction;
import bean.TransactionList;
import dao.TransactionDAO;
import dao.UserDAO;
import util.SendMail;

public class ShippingStatusUpdateServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// エラー発生時に使用する変数
		String error = "";
		String cmd = "";

		String  strTransactionId=request.getParameter("transactionId");

		int transactionId = Integer.parseInt(request.getParameter("transactionId"));

		TransactionDAO transactionDao = new TransactionDAO();

		UserDAO userDao = new UserDAO();

		Transaction transaction = new Transaction();

		TransactionList transactionlist = new TransactionList();

		Product product = new Product();

		SendMail sendmail = new SendMail();

		String BuyerName;

		String mailText;

		try {

			transactionDao.updateShippingStatus(strTransactionId);

			BuyerName = userDao.selectByBuyer(transactionId);

			transactionlist = transactionDao.selectByProduct(transactionId);

			mailText = BuyerName + "様\n\n以下の商品が発送されたことをご連絡いたします。\n\n"
					+ "商品名:" + transactionlist.getProductName() + " 価格:" +  transactionlist.getPrice()
					+ "円\n\nまたのご利用お待ちしております。";


			sendmail.sendmail("ご購入された商品の発送についてのお知らせ", mailText);





		} catch (IllegalStateException e) {

			// DB接続エラー時の処理

			error = "DB接続エラーの為、、発送確認を行うことが出来ませんでした。";
			cmd = "userLogout";

		} finally {

			// エラーが発生しなければ通常の処理
			if (error.equals("")) {

				request.getRequestDispatcher("/dealList").forward(request, response);

				// エラーが発生した場合はエラーメッセージとcmdを登録し、エラー画面へ遷移
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/view/error.jsp");

				dispatcher.forward(request, response);

			}
		}

	}



}
