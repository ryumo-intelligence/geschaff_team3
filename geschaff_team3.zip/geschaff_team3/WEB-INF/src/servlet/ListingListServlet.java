package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Product;
import bean.TransactionList;
import dao.ProductDAO;
import dao.TransactionDAO;
import dao.TransactionListDAO;



public class ListingListServlet extends HttpServlet{

	//doGetメソッドを定義
		public void doGet(HttpServletRequest request ,HttpServletResponse response)
				throws ServletException ,IOException{

			String error = "";
			String cmd = "";
	try {
		//文字コード指定
		request.setCharacterEncoding("UTF-8");

		ProductDAO productDao = new ProductDAO();

		TransactionListDAO transactionListDao = new TransactionListDAO();

		ArrayList<Product> productList = productDao.selectAll();

		ArrayList<TransactionList> transactionList = transactionListDao.selectAll();

		request.setAttribute("productList", productList);
		request.setAttribute("transactionList",transactionList);

	}catch (IllegalStateException e) {
		error = "DB接続エラーの為、登録できませんでした。";
		cmd = "adminLogout";
	}finally {

		if(error.equals("")) {
			//フォワードの実行
			request.getRequestDispatcher("/view/listingList.jsp").forward(request, response);
		}else {
		request.setAttribute("error", error);
		request.setAttribute("cmd", cmd);
		request.getRequestDispatcher("/view/error.jsp").forward(request, response);
		}
	}

	}

}