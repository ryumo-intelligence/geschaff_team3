package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import dao.UserDAO;

public class RegisterServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{

		String error = "";
		String cmd = "";

		try {


			//BookDAOのオブジェクト生成
			UserDAO userDao = new UserDAO();

			//画面から入力情報を受け取るためのエンコード設定
			request.setCharacterEncoding("UTF-8");

			//画面から入力情報を受け取る
			String email = (String)request.getParameter("email");
			String password = (String)request.getParameter("password");
			String name = (String)request.getParameter("name");
			String nameKana = (String)request.getParameter("nameKana");
			String authority = (String)request.getParameter("authority");
			String userName = (String)request.getParameter("userName");
			String birthday = (String)request.getParameter("birthday");
			String address = (String)request.getParameter("address");

			//メアド空白チェック
			if(email.equals("")) {
				error = "メールアドレスが未入力の為、新規登録処理は行えませんでした。";
				cmd = "userLogout";
				return;
			}

			//パスワ空白チェック
			if(password.equals("")) {
				error = "パスワード未入力の為、新規登録処理は行えませんでした。";
				cmd = "userLogout";
				return;
			}

			//ユーザーネーム空白チェック
			if(userName.equals("")) {
				error = "ユーザーネーム未入力の為、新規登録処理は行えませんでした。";
				cmd = "userLogout";
				return;
			}
			//名前空白チェック
			if(name.equals("")) {
				error = "氏名未入力の為、新規登録処理は行えませんでした。";
				cmd = "userLogout";
				return;
			}

			//名前かな空白チェック
			if(nameKana.equals("")) {
				error = "氏名(かな)未入力の為、新規登録処理は行えませんでした。";
				cmd = "userLogout";
				return;
			}

			//誕生日空白チェック
			if(birthday.equals("")) {
				error = "生年月日未入力の為、新規登録処理は行えませんでした。";
				cmd = "userLogout";
				return;
			}

			//住所空白チェック
			if(address.equals("")) {
				error = "住所未入力の為、新規登録処理は行えませんでした。";
				cmd = "userLogout";
				return;
			}

			ArrayList<User> userList = userDao.selectAll();
			for (int i = 0 ; i < userList.size(); i++) {
				if (email.equals(userList.get(i).getEmail())) {
					error = "そのメールドレスはすでに使用されています！もう一度入力してください。";
					cmd = "userLogout";
					return;
				}
			}

			//登録する書籍情報を格納するBookオブジェクトの生成
			User user = new User();
			//Bookオブジェクトに受け取った情報を格納
			user.setEmail(email);
			user.setPassword(password);
			user.setName(name);
			user.setNameKana(nameKana);
			user.setAuthority(authority);
			user.setUserName(userName);
			user.setBirthday(birthday);
			user.setAddress(address);

			//BookDAOクラスに定義したinsert()メソッドを利用して、Userオブジェクトに格納されたユーザーデータをデータベースに登録
			userDao.insert(user);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、新規登録できませんでした。";
			cmd = "userLogout";

		}finally {

			if(error.equals("")) {
				//ListServletへフォワード
				request.getRequestDispatcher("/view/userLogin.jsp").forward(request, response);

			} else {

				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				request.getRequestDispatcher("/view/error.jsp").forward(request, response);
			}

		}



	}
}
