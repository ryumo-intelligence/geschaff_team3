package servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.User;
import dao.UserDAO;

public class RegisterServlet extends HttpServlet {
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{
		//BookDAOのオブジェクト生成
		UserDAO userDao = new UserDAO();

		//画面から入力情報を受け取るためのエンコード設定
		request.setCharacterEncoding("UTF-8");

		//画面から入力情報を受け取る
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String nameKana = request.getParameter("nameKana");
		String authority = request.getParameter("authority");
		String userName = request.getParameter("userName");
		String birthday = request.getParameter("birthday");
		String address = request.getParameter("address");


		//登録する書籍情報を格納するBookオブジェクトの生成
		User user = new User();
		//Bookオブジェクトに受け取った情報を格納
		user.setEmail(email);
		user.setPassword(password);
		user.setName(name);
		user.setNameKana(nameKana);
		user.setAuthority(authority);
		user.setUserName(userName);
		user.setBirthday(birthday);
		user.setAddress(address);

		//BookDAOクラスに定義したinsert()メソッドを利用して、Userオブジェクトに格納されたユーザーデータをデータベースに登録
		userDao.insert(user);

	}
}



