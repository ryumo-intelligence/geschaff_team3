package servlet;

/*
 * プロジェクト名：フリマアプリ
 * 作成者：梅谷夏詩姫
 * 作成日時：2022/06/22
 */

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

import bean.Product;
import dao.ProductDAO;

public class ListingServlet {

	//doGetメソッドを定義
	public void doGet(HttpServletRequest request ,HttpServletResponse response)
			throws ServletException ,IOException{

		String error = "";
		String cmd = "";

		try {

			//文字コード指定
			request.setCharacterEncoding("UTF-8");

			//パラメータの取得
			String productName= request.getParameter("productName");		//商品名
			String strPrice = request.getParameter("price");				//価格
			String productGenre = request.getParameter("productGenre");		//商品ジャンル
			String productStatus = request.getParameter("productStatus");	//商品状態
			String productText = request.getParameter("productText");		//説明文

			//商品名空白チェック
			if(productName.equals("")) {
				error = "商品名が未入力の為、出品登録処理は行えませんでした。";
				cmd = "menu";
				return;
			}

			//金額空白チェック
			if(strPrice.equals("")) {
				error = "価格が未入力の為、出品登録書理は行えませんでした。";
				cmd = "menu";
				return;
			}

			//整数かどうかのチェック
			int price;
			try {
				price = Integer.parseInt(strPrice);
			}catch(NumberFormatException e) {
				error = "価格の値が不正な為、出品登録処理は行えませんでした。";
				cmd = "manu";
				return;
			}

			//オブジェクト生成
			ProductDAO proobj = new ProductDAO();

			//setterメソッドを利用
			Product product = new Product();
			product.setProductName(productName);
			product.setPrice(price);
			product.setProductGenre(productGenre);
			product.setProductStatus(productStatus);
			product.setProductText(productText);

			//オブジェクトに格納 ↓DAO作ってないエラーになるためコメントになっている
			proobj.insert(product);

		}catch(IllegalStateException e) {
			error = "DB接続エラーの為、登録できませんでした。";
			cmd = "logout";

		}finally {

			if(error.equals("")) {
				//フォワードの実行
				request.getRequestDispatcher("/listing").forward(request, response);
			}
			request.setAttribute("error", error);
			request.setAttribute("cmd", cmd);
			request.getRequestDispatcher("/view/error.jsp").forward(request, response);

		}

	}

}

