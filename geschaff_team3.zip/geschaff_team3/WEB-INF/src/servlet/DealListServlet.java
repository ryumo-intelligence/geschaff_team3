package servlet;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.Product;
import bean.Transaction;
import bean.TransactionList;
import bean.User;
import dao.ProductDAO;
import dao.TransactionDAO;
import dao.TransactionListDAO;
import dao.UserDAO;

public class DealListServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// エラー発生時に使用する変数
		String error = "";
		String cmd = "";

		UserDAO userDao = new UserDAO();

		ProductDAO productDao = new ProductDAO();

		TransactionDAO transactionDao = new TransactionDAO();

		TransactionListDAO transactionListDao = new TransactionListDAO();

		Product product = new Product();

		Transaction transaction = new Transaction();

		User usr = new User();

		TransactionList transactionList = new TransactionList();

		HttpSession session = request.getSession();

		// 取得するデータのエンコード処理
		request.setCharacterEncoding("UTF-8");

		try {

			User user = (User) session.getAttribute("user");

			// セッション切れの場合はerror.jspに遷移する
			if (user == null) {
				error = "セッション切れの為、購入処理を行えませんでした。";
				cmd = "logout";
				return;
			}

			ArrayList<TransactionList> list = transactionListDao.selectByEmail(user.getEmail());






		} catch (IllegalStateException e) {

				// DB接続エラー時の処理

				error = "DB接続エラーの為、、詳細情報は表示できませんでした。";
				cmd = "logout";


		} finally {

			// エラーが発生しなければ通常の処理
			if (error.equals("")) {

					request.getRequestDispatcher("/view/dealList.jsp").forward(request, response);

				// エラーが発生した場合はエラーメッセージとcmdを登録し、エラー画面へ遷移
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/view/error.jsp");

				dispatcher.forward(request, response);

			}
		}

	}

}
