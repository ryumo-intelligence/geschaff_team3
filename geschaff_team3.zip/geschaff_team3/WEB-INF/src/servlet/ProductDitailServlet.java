package servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Product;
import dao.ProductDAO;



public class ProductDitailServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		// エラー発生時に使用する変数
		String error = "";
		String cmd = "";

		ProductDAO productDao = new ProductDAO();

		Product product = new Product();

		// 取得するデータのエンコード処理
		request.setCharacterEncoding("UTF-8");

		// 商品IDを取得
		int productId = Integer.parseInt((String)request.getParameter("productId"));

		try {

			// 取得したIDの商品情報を取得

			//DAO未完成の為コメントアウト
			//product = productDao.selectByProductId(productId);

			if (product.getProductId() == 0) {
					// 取得したIDの商品データが存在しない場合の処理
					error = "商品データが存在しないため、詳細情報は表示できませんでした。  ";
					cmd = "menu";
					return;
			}

			// 取得した書籍データをリクエストスコープに登録
			request.setAttribute("product", product);

		} catch (IllegalStateException e) {

				// DB接続エラー時の処理

				error = "DB接続エラーの為、、詳細情報は表示できませんでした。";
				cmd = "logout";


		} finally {

			// エラーが発生しなければ通常の処理
			if (error.equals("")) {

					request.getRequestDispatcher("/view/productDetail.jsp").forward(request, response);

				// エラーが発生した場合はエラーメッセージとcmdを登録し、エラー画面へ遷移
			} else {
				request.setAttribute("error", error);
				request.setAttribute("cmd", cmd);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/view/error.jsp");

				dispatcher.forward(request, response);

			}
		}

	}
}


