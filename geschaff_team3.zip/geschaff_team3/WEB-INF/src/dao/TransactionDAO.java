package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Product;
import bean.Transaction;
import bean.TransactionList;

public class TransactionDAO {

	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/shoppingdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	// DB接続処理
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public void insert(Transaction transaction) {

		Connection con = null;
		Statement smt = null;

		try {

			con = getConnection();
			smt = con.createStatement();

			// SQLを登録
			String sql = "INSERT INTO transactioninfo VALUES(NULL," + transaction.getProductId() + ",'"
					+ transaction.getBuyerEmail() + "','" + transaction.getSellerEmail() + "','0','0')";

			// SQLを実行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	// 書籍データを更新するメソッド
	public void updateShippingStatus(String transactionId) {

		Connection con = null;
		Statement smt = null;

		try {

			con = getConnection();
			smt = con.createStatement();

			// SQL文を格納
			String sql = "UPDATE transactioninfo SET shipping_status='1' WHERE transaction_id='"
					+ transactionId + "'";
			// SQLを「実行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public void updatePaymentStatus(String transactionId) {

		Connection con = null;
		Statement smt = null;

		try {

			con = getConnection();
			smt = con.createStatement();

			// SQL文を格納
			String sql = "UPDATE transactioninfo SET payment_status='1' WHERE transaction_id='"
					+ transactionId + "'";
			// SQLを「実行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}


	public Transaction  selectByTransactionId(int transactionId) {

		Connection con = null;
		Statement smt = null;

		Transaction transaction = new Transaction();

		try {
			con = getConnection();
			smt = con.createStatement();
			// SQLを登録
			String sql = "SELECT * FROM transactioninfo WHERE user ='"+ transactionId +"'";


			// SQLを実行
			ResultSet rs = smt.executeQuery(sql);

			// Bookオブジェクトに取得したデータを格納
			if(rs.next()) {
				transaction.setTransactionId(rs.getInt("transaction_id"));
				transaction.setProductId(rs.getInt("product_id"));
				transaction.setBuyerEmail(rs.getString("buyer_email"));
				transaction.setSellerEmail(rs.getString("seller_email"));
				transaction.setShippingStatus(rs.getString("shipping_status"));
				transaction.setPaymentStatus(rs.getString("payment_status"));

			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return transaction;
	}

	public TransactionList  selectByProduct(int transactionId) {

		Connection con = null;
		Statement smt = null;

		TransactionList transactionlist  = new TransactionList ();

		try {
			con = getConnection();
			smt = con.createStatement();
			// SQLを登録
			String sql = "SELECT p.product_name,p.price,t.buyer_email FROM transactioninfo t INNER JOIN productinfo p ON t.product_id=p.product_id WHERE t.transaction_id ='" + transactionId + "'";


			// SQLを実行
			ResultSet rs = smt.executeQuery(sql);

			// Bookオブジェクトに取得したデータを格納
			if(rs.next()) {
				transactionlist.setProductName(rs.getString("p.product_name"));
				transactionlist.setPrice(rs.getInt("p.price"));
				transactionlist.setBuyerEmail(rs.getString("t.buyer_email"));

			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return transactionlist;
	}


}
