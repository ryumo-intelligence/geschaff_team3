package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.Product;

public class ProductDAO {

	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/shoppingdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	// DB接続処理
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public ArrayList<Product> selectAll(){

		ArrayList<Product> productList = new ArrayList<Product>();
		String  sql = "SELECT * FROM produtinfo ORDER BY product_id";

		Connection con = null;
		Statement smt = null;
		try {
			// getConnection()メソッドを利用してConnectionオブジェクトを生成します。
			con = getConnection();
			// createStatement()メソッドを利用してStatementオブジェクトを生成します。
			smt = con.createStatement();

			// リザルトセットをProduct型にセットする
			ResultSet rs = smt.executeQuery(sql);

			while (rs.next()) {
				Product product = new Product();
				product.setProductId(rs.getInt("product_id"));
				product.setProductName(rs.getString("product_name"));
				product.setPrice(rs.getInt("price"));
				product.setSalseStatus(rs.getString("salse_status"));

				productList.add(product);
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {smt.close();} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {con.close();} catch (SQLException ignore) {}
			}
		}
		return productList;
	}

	public Product selectByProductId(int productId) {

		Connection con = null;
		Statement smt = null;
		String sql = "SELECT * FROM productinfo WHERE product_id = " + productId ;

		Product product = new Product();

		try {
			// getConnection()メソッドを利用してConnectionオブジェクトを生成します。
			con = getConnection();
			// createStatement()メソッドを利用してStatementオブジェクトを生成します。
			smt = con.createStatement();
			// 結果セットから商品情報を取り出し、Productオブジェクトに格納します。
			ResultSet rs = smt.executeQuery(sql);

			// リザルトセットをProduct型にセットする
			while (rs.next()) {
				product.setProductId(rs.getInt("product_id"));
				product.setSellerEmail(rs.getString("seller_email"));
				product.setSalseStatus(rs.getString("sales_status"));
				product.setProductStatus(rs.getString("product_status"));
				product.setProductName(rs.getString("product_name"));
				product.setPrice(rs.getInt("price"));
				product.setProductText(rs.getString("product_text"));
				product.setProductGenre(rs.getString("product_genre"));
			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {smt.close();} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {con.close();} catch (SQLException ignore) {}
			}
		}
		return product;
	}

	public void insert(Product product) {

		Connection con = null;
		Statement smt = null;
		// SQLを登録
					String sql = "INSERT INTO productinfo VALUES (NULL, ' " + product.getSellerEmail() + "', '" + product.getSalseStatus() + "', '" + 0 + "'"
							+ ", '" + product.getProductName() + "', " + product.getPrice() + ", '" + product.getProductText() + "', '" + product.getProductGenre() + "')";

		try {
			// getConnection()メソッドを利用してConnectionオブジェクトを生成します。
			con = getConnection();
			// createStatement()メソッドを利用してStatementオブジェクトを生成します。
			smt = con.createStatement();

			// SQLを実行
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
	}

	public void update(Product product) {
		Connection con = null;
		Statement smt = null;
		String sql = "UPDATE productinfo SET salseStatus='"+ 1 +"' WHERE product_id ='"+ product.getProductId() +"'";
		try {
			// getConnection()メソッドを利用してConnectionオブジェクトを生成します。
			con = getConnection();
			// createStatement()メソッドを利用してStatementオブジェクトを生成します。
			smt = con.createStatement();
			// SQL文を発行し販売状況を変更します。
			smt.executeUpdate(sql);

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {smt.close();} catch (SQLException ignore) {}
			}
			if (con != null) {
				try {con.close();} catch (SQLException ignore) {}
			}
		}
	}
}