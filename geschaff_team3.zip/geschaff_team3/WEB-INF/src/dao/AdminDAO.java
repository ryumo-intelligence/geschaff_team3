package dao;

public class AdminDAO {

}
