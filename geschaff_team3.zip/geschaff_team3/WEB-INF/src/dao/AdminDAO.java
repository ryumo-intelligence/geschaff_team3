package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.Admin;

public class AdminDAO {

	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/shoppingdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public Admin selectByUser(String email,String password) {
		Connection con = null;
		Statement smt = null;

		Admin admin = new Admin();

		try {
			// ②引数の情報を利用し、検索用のSQL文を文字列として定義します。
			String sql = "SELECT * FROM admininfo WHERE email ='"+ email +"' AND password='"+password+"'";

			// ③BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成します。
			con = getConnection();
			// ④ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成します。
			smt = con.createStatement();
			// ⑤Statementオブジェクトの、executeQuery（）メソッドを利用して、②のSQL文を発行し結果セットを取得します。
			ResultSet rs = smt.executeQuery(sql);
			// ⑥結果セットから管理者データを取り出し、Adminオブジェクトに格納します。
			while (rs.next()) {
				admin.setEmail(rs.getString("email"));
				admin.setPassword(rs.getString("password"));
				admin.setAuthority(rs.getString("authority"));
			}
		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return admin;
	}

}