package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import bean.Transaction;

public class TransactionListDAO {

	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/shoppingdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	// DB接続処理
	public static Connection getConnection() {
		try {
			Class.forName(RDB_DRIVE);
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);
			return con;
		} catch (Exception e) {
			throw new IllegalStateException(e);
		}
	}

	public Transaction  selectByEmail(String email) {

		Connection con = null;
		Statement smt = null;

		Transaction transaction = new Transaction();

		try {
			con = getConnection();
			smt = con.createStatement();
			// SQLを登録
			String sql = "SELECT t.transaction_id,p.product_name,p.price,t.buyer_email,t.seller_email,p.product_status,t.shipping_status,t.payment_status FROM "
					+ "transactioninfo t INNER JOIN productinfo p ON t.product_id=p.product_id  WHERE t.buyer_email = '" + email +"' OR t.seller_email = '" + email +"'";


			// SQLを実行
			ResultSet rs = smt.executeQuery(sql);

			// Bookオブジェクトに取得したデータを格納
			if(rs.next()) {

			}

		} catch (Exception e) {
			throw new IllegalStateException(e);
		} finally {
			if (smt != null) {
				try {
					smt.close();
				} catch (SQLException ignore) {
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException ignore) {
				}
			}
		}
		return transaction;
	}

}
