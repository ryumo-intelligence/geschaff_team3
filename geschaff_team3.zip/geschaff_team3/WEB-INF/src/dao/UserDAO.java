package dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import bean.User;

public class UserDAO {
	//DB接続情報をフィールド変数に定義
	private static String RDB_DRIVE = "com.mysql.jdbc.Driver";
	private static String URL = "jdbc:mysql://localhost/shoppingdb";
	private static String USER = "root";
	private static String PASSWD = "root123";

	//DB接続を行うメソッド定義
	private static Connection getConnection() {
		try {
			//JDBCドライバーを読み込む
			Class.forName(RDB_DRIVE);

			/* DriverManagerクラスのgetConnection()メソッドを利用し、
			 * データベースへ接続する
			 */
			Connection con = DriverManager.getConnection(URL, USER, PASSWD);

			//戻り値としてコネクション情報を返す
			return con;
		}catch(Exception e) {
			throw new IllegalStateException(e);
		}
	}

	//指定ユーザーとパスワードの条件に合致する情報を取得する
	public User selectByUser(String email, String password) {
		Connection con = null;
		Statement smt = null;

		//検索したユーザー情報を格納するUserオブジェクトを生成
		User user = new User();

		//SQL文
		String sql = "SELECT * FROM userinfo WHERE email ='"+email+"' AND password='"+password+"'";

		try {
			//UserDaoに定義したgetConnection()メソッドを利用してConnectionオブジェクトを生成
			con = UserDAO.getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			//SQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);

			//取得した結果セットを元にデータを取り出し、Userオブジェクトに格納
			if(rs.next()) {
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				user.setName(rs.getString("name"));
				user.setNameKana(rs.getString("name_kana"));
				user.setAuthority(rs.getString("authority"));
				user.setUserName(rs.getString("user_name"));
				user.setBirthday(rs.getString("birthday"));
				user.setAddress(rs.getString("address"));
			}

		}catch(Exception e) {
			throw new IllegalStateException(e);
		}finally {
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return user;
	}

	//DBのuserinfoテーブルに新規登録処理を行うメソッド
	public void insert(User user) {
		Connection con = null;
		Statement smt = null;
		//登録用のSQLを文字列として定義
		String sql = "INSERT INTO userinfo VALUES('"+ user.getEmail() +"','"+ user.getPassword() +"','"+ user.getName() +"','"+ user.getNameKana() +"','1','"+ user.getUserName() +"','"+ user.getBirthday() +"','"+ user.getAddress() + "')";

		try {
			//OrderDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = UserDAO.getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();
			//SQL文を発行し書籍データを登録
			int getData = smt.executeUpdate(sql);

		}catch(Exception e) {
			throw new IllegalStateException(e);
		}finally {
			if(smt != null) {
				try{smt.close();}catch(SQLException ignore) {}
			}
			if(con != null) {
				try{con.close();}catch(SQLException ignore){}
			}
		}
	}

	//ユーザー一覧機能
	public ArrayList<User> selectAll(){

		Connection con = null;
		Statement smt = null;
		//検索した書籍情報を格納するArrayListオブジェクト
		ArrayList<User> userList = new ArrayList<User>();
		//SQL文を文字列として定義
		String sql = "SELECT * FROM userinfo ORDER BY email";

		try {
			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = UserDAO.getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();
			//SQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);

			//結果セットから書籍データを検索件数分全て取り出し、AllayListオブジェクトにBookオブジェクトとして格納
			while(rs.next()) {
				User user = new User();
				user.setEmail(rs.getString("email"));
				user.setPassword(rs.getString("password"));
				user.setUserName(rs.getString("user_name"));
				userList.add(user);
			}

		}catch(Exception e) {
			throw new IllegalStateException(e);
		}finally {
			if( smt != null) {
				try {smt.close();}catch(SQLException ignore) {}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return userList;
	}

	//データベースから指定されたユーザーネームを検索しBookオブジェクトに格納するメソッド
	public String selectBySeller(int productId){

		Connection con = null;
		Statement smt = null;

		//検索した書籍情報を格納する変数Userを生成
		String userName = null;

		//SQL文
		String sql = "SELECT u.user_name FROM productinfo p INNER JOIN userinfo u ON p.seller_email = u.email WHERE p.product_id =" + productId;

		try{
			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = UserDAO.getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			//SQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);

			//結果セットから書籍データを取り出し、変数userNameに格納
			if(rs.next()) {
				userName = rs.getString("user_name");
			}

		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return userName;
	}

	public String selectByBuyer(int transactionId){

		Connection con = null;
		Statement smt = null;

		//検索した書籍情報を格納する変数Userを生成
		String userName = null;

		//SQL文
		String sql = "SELECT u.user_name FROM transactioninfo t INNER JOIN userinfo u ON t.buyer_email = u.email WHERE t.transaction_id =" + transactionId;

		try{
			//BookDAOクラスに定義した、getConnection()メソッドを利用してConnectionオブジェクトを生成
			con = UserDAO.getConnection();
			//ConnectionオブジェクトのcreateStatement（）メソッドを利用してStatementオブジェクトを生成
			smt = con.createStatement();

			//SQL文を発行し結果セットを取得
			ResultSet rs = smt.executeQuery(sql);

			//結果セットから書籍データを取り出し、変数userNameに格納
			if(rs.next()) {
				userName = rs.getString("user_name");
			}

		}catch(Exception e){
			throw new IllegalStateException(e);
		}finally{
			if( smt != null ){
				try{smt.close();}catch(SQLException ignore){}
			}
			if( con != null ){
				try{con.close();}catch(SQLException ignore){}
			}
		}
		return userName;
	}



}