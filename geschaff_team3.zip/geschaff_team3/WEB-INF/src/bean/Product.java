package bean;

public class Product {

		private int productId;//商品ID
		private String sellerEmail; //出品者のメールアドレス
		private String salseStatus;//販売状況(0:売切,1:販売中)
		private String productStatus;//商品状態
		private String productName;//商品名
		private int price;//価格
		private String productText;//説明文
		private String productGenre;//商品ジャンル



		public Product() {
			this.productId = 0;
			this.sellerEmail = null;
			this.salseStatus = null;
			this.productStatus = null;
			this.productName = null;
			this.price = 0;
			this.productText = null;
			this.productGenre = null;
		}

		//ゲッターメソッド
		public int getProductId() {

			return productId;
		}
		public String getSellerEmail() {

			return sellerEmail;
		}
		public String getSalseStatus() {

			return salseStatus;
		}
		public String getProductStatus() {

			return productStatus;
		}

		public String getProductName() {

			return productName;
		}

		public int getPrice() {

			return price;
		}

		public String getProductText() {

			return productText;
		}

		public String getProductGenre() {

			return productGenre;
		}


		//セッターメソッド
		public void setProductId(int productId) {

			this.productId = productId;
		}
		public void setSellerEmail(String sellerEmail) {

			this.sellerEmail = sellerEmail;
		}

		public void setSalseStatus(String salseStatus) {

			this.salseStatus = salseStatus;
		}

		public void setProductStatus(String productStatus) {

			this.productStatus = productStatus;
		}

		public void setProductName(String productName) {

			this.productName = productName;
		}

		public void setPrice(int price) {

			this.price = price;
		}

		public void setProductText(String productText) {

			this.productText = productText;
		}

		public void setProductGenre(String productGenre) {

			this.productGenre = productGenre;
		}

	}


