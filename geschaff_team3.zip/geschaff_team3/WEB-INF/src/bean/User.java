
package bean;

public class User {

	private String email; // メールアドレス
	private String password; // パスワード
	private String name;//名前
	private String nameKana;//名前(かな)
	private String authority; // 権限（0：管理者 1：一般ユーザー、）
	private String userName; // ユーザーネーム
	private String birthday; // 生年月日
	private String address; // 住所




	public User() {
		this.email = null;
		this.password = null;
		this.name = null;
		this.nameKana = null;
		this.authority = null;
		this.userName = null;
		this.birthday = null;
		this.address = null;
	}

	//ゲッターメソッド
	public String getEmail() {

		return email;
	}
	public String getPassword() {

		return password;
	}
	public String getName() {

		return name;
	}
	public String getNameKana() {

		return nameKana;
	}

	public String getAuthority() {

		return authority;
	}

	public String getUserName() {

		return userName;
	}

	public String getBirthday() {

		return birthday;
	}

	public String getAddress() {

		return address;
	}


	//セッターメソッド
	public void setEmail(String email) {

		this.email = email;
	}
	public void setPassword(String password) {

		this.password = password;
	}

	public void setName(String name) {

		this.name = name;
	}

	public void setNameKana(String nameKana) {

		this.nameKana = nameKana;
	}

	public void setAuthority(String authority) {

		this.authority = authority;
	}

	public void setUserName(String userName) {

		this.userName = userName;
	}

	public void setBirthday(String birthday) {

		this.birthday = birthday;
	}

	public void setAddress(String address) {

		this.address = address;
	}

}
