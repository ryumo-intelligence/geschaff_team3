package bean;

public class TransactionList {

	private int transactionId;// 取引ID
	private String productName;// 購入商品名
	private int price;// 価格
	private String buyerEmail;// 購入者メールアドレス
	private String sellerEmail;// 出品者メールアドレス
	private String productStatus;// 販売状況
	private String shippingStatus;// 発送ステータス(0:発送準備中、1:発送済み)
	private String paymentStatus;// 入金状況(0:入金前、1:入金済み)

	public TransactionList() {
		this.transactionId = 0;
		this.productName = null;
		this.price = 0;
		this.buyerEmail = null;
		this.sellerEmail = null;
		this.productStatus = null;
		this.shippingStatus = null;
		this.paymentStatus = null;
	}

	// ゲッターメソッド
	public int getTransactionId() {

		return transactionId;
	}

	public String getProductName() {

		return productName;
	}

	public int getPrice() {

		return price;
	}

	public String getBuyerEmail() {

		return buyerEmail;
	}

	public String getSellerEmail() {

		return sellerEmail;
	}

	public String getProductStatus() {

		return productStatus;
	}

	public String getShippingStatuse() {

		return shippingStatus;
	}

	public String getPaymentStatus() {

		return paymentStatus;
	}

	// セッターメソッド
	public void setTransactionId(int transactionId) {

		this.transactionId = transactionId;
	}

	public void setProductName(String productName) {

		this.productName = productName;
	}

	public void setPrice(int price) {

		this.price = price;
	}

	public void setBuyerEmail(String buyerEmail) {

		this.buyerEmail = buyerEmail;
	}

	public void setSellerEmail(String sellerEmail) {
		
		this.sellerEmail = sellerEmail;
	}
	public void setProductStatus(String productStatus) {

		this.productStatus = productStatus;
	}


	public void setShippingStatus(String shippingStatus) {

		this.shippingStatus = shippingStatus;
	}

	public void setPaymentStatus(String paymentStatus) {

		this.paymentStatus = paymentStatus;
	}

}
