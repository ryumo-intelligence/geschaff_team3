package bean;

public class Transaction {

	private int transaction_id;//取引ID
	private int product_id;//購入商品ID
	private String buyer_email;//購入者メールアドレス
	private String seller_email;//出品者メールアドレス
	private String shipping_status;//発送ステータス(0:発送準備中、1:発送済み)
	private String payment_status;//入金状況(0:入金前、1:入金済み)



	public Transaction() {
		this.transaction_id = 0;
		this.product_id = 0;
		this.buyer_email = null;
		this.seller_email = null;
		this.shipping_status = null;
		this.payment_status = null;
	}

	//ゲッターメソッド
	public int getTransaction_id() {

		return transaction_id;
	}
	public int getProduct_id() {

		return product_id;
	}
	public String getBuyer_email() {

		return buyer_email;
	}
	public String getSeller_email() {

		return seller_email;
	}

	public String getShipping_statuse() {

		return shipping_status;
	}

	public String getPayment_status() {

		return payment_status;
	}


	//セッターメソッド
	public void setTransaction_id(int transaction_id) {

		this.transaction_id = transaction_id;
	}
	public void setProduct_id(int product_id) {

		this.product_id = product_id;
	}

	public void setBuyer_email(String buyer_email) {

		this.buyer_email = buyer_email;
	}
	public void setSeller_email(String seller_email) {

		this.seller_email = seller_email;
	}


	public void setShipping_status(String shipping_status) {

		this.shipping_status = shipping_status;
	}

	public void setPayment_status(String payment_status) {

		this.payment_status = payment_status;
	}


}
