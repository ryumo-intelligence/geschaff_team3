package bean;

public class Transaction {

	private int transactionId;//取引ID
	private int productId;//購入商品ID
	private String buyerEmail;//購入者メールアドレス
	private String sellerEmail;//出品者メールアドレス
	private String shippingStatus;//発送ステータス(0:発送準備中、1:発送済み)
	private String paymentStatus;//入金状況(0:入金前、1:入金済み)



	public Transaction() {
		this.transactionId = 0;
		this.productId = 0;
		this.buyerEmail = null;
		this.sellerEmail = null;
		this.shippingStatus = null;
		this.paymentStatus = null;
	}

	//ゲッターメソッド
	public int getTransactionId() {

		return transactionId;
	}
	public int getProductId() {

		return productId;
	}
	public String getBuyerEmail() {

		return buyerEmail;
	}
	public String getSellerEmail() {

		return sellerEmail;
	}

	public String getShippingStatuse() {

		return shippingStatus;
	}

	public String getPaymentStatus() {

		return paymentStatus;
	}


	//セッターメソッド
	public void setTransactionId(int transactionId) {

		this.transactionId = transactionId;
	}
	public void setProductId(int productId) {

		this.productId = productId;
	}

	public void setBuyerEmail(String buyerEmail) {

		this.buyerEmail = buyerEmail;
	}
	public void setSellerEmail(String sellerEmail) {

		this.sellerEmail = sellerEmail;
	}


	public void setShippingStatus(String shippingStatus) {

		this.shippingStatus = shippingStatus;
	}

	public void setPaymentStatus(String paymentStatus) {

		this.paymentStatus = paymentStatus;
	}


}
