package bean;

public class Admin {

	private String email;//メールアドレス
	private String password;//パスワード
	private String authority;//権限(0:管理者・1:ユーザー)


	public Admin() {
		this.email = null;
		this.password = null;
		this.authority = null;
	}

	public String getEmail() {

		return email;
	}

	public String getPassword() {

		return password;
	}


	public String getAuthority() {

		return authority;
	}

	public void setEmail(String email) {

		this.email = email;
	}

	public void setPassword(String password) {

		this.password = password;
	}


	public void setAuthority(String authority) {

		this.authority = authority;
	}
}
